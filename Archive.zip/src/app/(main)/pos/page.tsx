"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Search, Plus, Trash2, CreditCard, Smartphone, ShoppingCart } from "lucide-react"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface CartItem {
  id: string
  name: string
  variant: string
  imei: string
  price: number
  quantity: number
}

export default function POSInterface() {
  const [searchTerm, setSearchTerm] = useState("")
  const [cart, setCart] = useState<CartItem[]>([])
  const [selectedProduct, setSelectedProduct] = useState<any>(null)

  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  })
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card">("cash")
  const [isCheckoutDialogOpen, setIsCheckoutDialogOpen] = useState(false)
  const [amountReceived, setAmountReceived] = useState("")

  const products = [
    {
      id: "1",
      name: "iPhone 15 Pro Max",
      variants: [
        {
          id: "1-1",
          storage: "256GB",
          color: "Titan Tự Nhiên",
          price: 34990000,
          stock: 5,
          imeis: ["359123456789012", "359123456789013", "359123456789014"],
        },
        {
          id: "1-2",
          storage: "512GB",
          color: "Titan Đen",
          price: 40990000,
          stock: 3,
          imeis: ["359123456789015", "359123456789016"],
        },
        { id: "1-3", storage: "256GB", color: "Titan Xanh", price: 34990000, stock: 2, imeis: ["359123456789017"] },
      ],
    },
    {
      id: "2",
      name: "iPhone 15 Pro",
      variants: [
        {
          id: "2-1",
          storage: "128GB",
          color: "Titan Tự Nhiên",
          price: 28990000,
          stock: 4,
          imeis: ["359123456789018", "359123456789019"],
        },
        {
          id: "2-2",
          storage: "256GB",
          color: "Titan Xanh",
          price: 32990000,
          stock: 6,
          imeis: ["359123456789020", "359123456789021", "359123456789022"],
        },
      ],
    },
    {
      id: "3",
      name: "iPhone 15",
      variants: [
        {
          id: "3-1",
          storage: "128GB",
          color: "Hồng",
          price: 22990000,
          stock: 8,
          imeis: ["359123456789023", "359123456789024"],
        },
        {
          id: "3-2",
          storage: "256GB",
          color: "Xanh",
          price: 25990000,
          stock: 5,
          imeis: ["359123456789025", "359123456789026"],
        },
      ],
    },
  ]

  const filteredProducts = products.filter((product) => product.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const addToCart = (product: any, variant: any, imei: string) => {
    const cartItem: CartItem = {
      id: `${variant.id}-${imei}`,
      name: product.name,
      variant: `${variant.storage} ${variant.color}`,
      imei: imei,
      price: variant.price,
      quantity: 1,
    }
    setCart([...cart, cartItem])
    setSelectedProduct(null)
  }

  const removeFromCart = (id: string) => {
    setCart(cart.filter((item) => item.id !== id))
  }

  const getTotalAmount = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const handleCheckout = () => {
    alert("Chức năng thanh toán sẽ được triển khai")
  }

  const processPayment = () => {
    const total = getTotalAmount() * 1.1
    if (paymentMethod === "cash") {
      const received = Number.parseFloat(amountReceived)
      if (received < total) {
        alert("Số tiền nhận không đủ!")
        return
      }
    }

    // Process payment logic
    const orderData = {
      items: cart,
      customer: customerInfo,
      paymentMethod,
      total,
      amountReceived: paymentMethod === "cash" ? Number.parseFloat(amountReceived) : total,
      change: paymentMethod === "cash" ? Number.parseFloat(amountReceived) - total : 0,
    }

    console.log("Processing payment:", orderData)
    alert("Thanh toán thành công!")

    // Reset form
    setCart([])
    setCustomerInfo({ name: "", phone: "", email: "", address: "" })
    setAmountReceived("")
    setIsCheckoutDialogOpen(false)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Giao diện bán hàng (POS)</h2>
        <p className="text-gray-600">Tạo đơn hàng và xử lý thanh toán</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Product Selection */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Chọn sản phẩm</CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Tìm kiếm sản phẩm..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {filteredProducts.map((product) => (
                <div key={product.id} className="border rounded-lg p-4">
                  <h3 className="font-semibold text-lg mb-3">{product.name}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {product.variants.map((variant) => (
                      <div
                        key={variant.id}
                        className="border rounded-lg p-3 cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => setSelectedProduct({ product, variant })}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">
                              {variant.storage} - {variant.color}
                            </p>
                            <p className="text-sm text-gray-500">Còn {variant.stock} chiếc</p>
                          </div>
                          <Badge variant={variant.stock > 0 ? "default" : "secondary"}>
                            {variant.stock > 0 ? "Còn hàng" : "Hết hàng"}
                          </Badge>
                        </div>
                        <p className="text-lg font-bold text-blue-600">{variant.price.toLocaleString("vi-VN")}₫</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* IMEI Selection Modal */}
          {selectedProduct && (
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="text-blue-900">Chọn IMEI - {selectedProduct.product.name}</CardTitle>
                <CardDescription>
                  {selectedProduct.variant.storage} {selectedProduct.variant.color} -{" "}
                  {selectedProduct.variant.price.toLocaleString("vi-VN")}₫
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {selectedProduct.variant.imeis.map((imei: string) => (
                    <div
                      key={imei}
                      className="flex items-center justify-between p-3 bg-white rounded-lg border cursor-pointer hover:bg-gray-50"
                      onClick={() => addToCart(selectedProduct.product, selectedProduct.variant, imei)}
                    >
                      <div className="flex items-center space-x-3">
                        <Smartphone className="w-4 h-4 text-gray-500" />
                        <span className="font-mono text-sm">{imei}</span>
                      </div>
                      <Button size="sm">
                        <Plus className="w-4 h-4 mr-1" />
                        Thêm
                      </Button>
                    </div>
                  ))}
                </div>
                <div className="mt-4">
                  <Button variant="outline" onClick={() => setSelectedProduct(null)}>
                    Hủy
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Shopping Cart */}
        <div className="space-y-4">
          {/* Customer Information */}
          <Card className="mb-4">
            <CardHeader>
              <CardTitle className="text-sm">Thông tin khách hàng</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Input
                placeholder="Tên khách hàng"
                value={customerInfo.name}
                onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
              />
              <Input
                placeholder="Số điện thoại"
                value={customerInfo.phone}
                onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
              />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShoppingCart className="w-5 h-5 mr-2" />
                Giỏ hàng ({cart.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cart.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Chưa có sản phẩm nào</p>
              ) : (
                <>
                  {cart.map((item) => (
                    <div key={item.id} className="border rounded-lg p-3">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{item.name}</h4>
                          <p className="text-xs text-gray-500">{item.variant}</p>
                          <p className="text-xs text-gray-400 font-mono">IMEI: {item.imei}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFromCart(item.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Số lượng: {item.quantity}</span>
                        <span className="font-bold text-blue-600">{item.price.toLocaleString("vi-VN")}₫</span>
                      </div>
                    </div>
                  ))}

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Tạm tính:</span>
                      <span>{getTotalAmount().toLocaleString("vi-VN")}₫</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Thuế VAT (10%):</span>
                      <span>{(getTotalAmount() * 0.1).toLocaleString("vi-VN")}₫</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span>Tổng cộng:</span>
                      <span className="text-blue-600">{(getTotalAmount() * 1.1).toLocaleString("vi-VN")}₫</span>
                    </div>
                  </div>

                  <Button className="w-full" onClick={() => setIsCheckoutDialogOpen(true)} disabled={cart.length === 0}>
                    <CreditCard className="w-4 h-4 mr-2" />
                    Thanh toán
                  </Button>

                  {/* Checkout Dialog */}
                  <Dialog open={isCheckoutDialogOpen} onOpenChange={setIsCheckoutDialogOpen}>
                    <DialogContent className="sm:max-w-[500px]">
                      <DialogHeader>
                        <DialogTitle>Xác nhận thanh toán</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <h4 className="font-medium">Sản phẩm ({cart.length})</h4>
                          {cart.map((item) => (
                            <div key={item.id} className="flex justify-between text-sm">
                              <span>
                                {item.name} - {item.variant}
                              </span>
                              <span>{item.price.toLocaleString("vi-VN")}₫</span>
                            </div>
                          ))}
                        </div>

                        <Separator />

                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span>Tạm tính:</span>
                            <span>{getTotalAmount().toLocaleString("vi-VN")}₫</span>
                          </div>
                          <div className="flex justify-between">
                            <span>VAT (10%):</span>
                            <span>{(getTotalAmount() * 0.1).toLocaleString("vi-VN")}₫</span>
                          </div>
                          <div className="flex justify-between font-bold">
                            <span>Tổng cộng:</span>
                            <span>{(getTotalAmount() * 1.1).toLocaleString("vi-VN")}₫</span>
                          </div>
                        </div>

                        <Separator />

                        <div className="space-y-3">
                          <div>
                            <Label>Phương thức thanh toán</Label>
                            <Select
                              value={paymentMethod}
                              onValueChange={(value: "cash" | "card") => setPaymentMethod(value)}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="cash">Tiền mặt</SelectItem>
                                <SelectItem value="card">Thẻ ngân hàng</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {paymentMethod === "cash" && (
                            <div>
                              <Label>Số tiền nhận</Label>
                              <Input
                                type="number"
                                placeholder="Nhập số tiền khách đưa"
                                value={amountReceived}
                                onChange={(e) => setAmountReceived(e.target.value)}
                              />
                              {amountReceived && Number.parseFloat(amountReceived) >= getTotalAmount() * 1.1 && (
                                <p className="text-sm text-green-600 mt-1">
                                  Tiền thối:{" "}
                                  {(Number.parseFloat(amountReceived) - getTotalAmount() * 1.1).toLocaleString("vi-VN")}
                                  ₫
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsCheckoutDialogOpen(false)}>
                          Hủy
                        </Button>
                        <Button onClick={processPayment}>Xác nhận thanh toán</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
