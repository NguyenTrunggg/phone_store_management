"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Plus, Phone, Mail, MapPin, Calendar, DollarSign, ShoppingBag, User, Trash2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function CustomerManagement() {
  const [searchTerm, setSearchTerm] = useState("")

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null)
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    notes: "",
  })

  const customers = [
    {
      id: "1",
      name: "Nguyễn Văn An",
      phone: "0901234567",
      email: "nguyenvanan@email.com",
      address: "123 Nguyễn Huệ, Q1, TP.HCM",
      totalSpent: 67980000,
      orderCount: 2,
      lastPurchase: "2024-01-18",
      status: "vip",
    },
    {
      id: "2",
      name: "Trần Thị Bình",
      phone: "0912345678",
      email: "tranthibinh@email.com",
      address: "456 Lê Lợi, Q3, TP.HCM",
      totalSpent: 34990000,
      orderCount: 1,
      lastPurchase: "2024-01-15",
      status: "regular",
    },
    {
      id: "3",
      name: "Lê Minh Cường",
      phone: "0923456789",
      email: "leminhcuong@email.com",
      address: "789 Võ Văn Tần, Q3, TP.HCM",
      totalSpent: 91970000,
      orderCount: 3,
      lastPurchase: "2024-01-20",
      status: "vip",
    },
    {
      id: "4",
      name: "Phạm Thu Dung",
      phone: "0934567890",
      email: "phamthudung@email.com",
      address: "321 Pasteur, Q1, TP.HCM",
      totalSpent: 22990000,
      orderCount: 1,
      lastPurchase: "2024-01-12",
      status: "new",
    },
  ]

  const filteredCustomers = customers.filter(
    (customer) => customer.name.toLowerCase().includes(searchTerm.toLowerCase()) || customer.phone.includes(searchTerm),
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "vip":
        return <Badge className="bg-purple-100 text-purple-800">VIP</Badge>
      case "regular":
        return <Badge variant="secondary">Thường xuyên</Badge>
      case "new":
        return <Badge className="bg-green-100 text-green-800">Mới</Badge>
      default:
        return <Badge variant="outline">Khách hàng</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Quản lý khách hàng</h2>
          <p className="text-gray-600">Theo dõi thông tin và lịch sử mua hàng của khách hàng</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Thêm khách hàng
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Thêm khách hàng mới</DialogTitle>
              <DialogDescription>Tạo thông tin khách hàng trong hệ thống</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div>
                <Label htmlFor="name">Họ và tên</Label>
                <Input
                  id="name"
                  value={newCustomer.name}
                  onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                  placeholder="Nguyễn Văn A"
                />
              </div>
              <div>
                <Label htmlFor="phone">Số điện thoại</Label>
                <Input
                  id="phone"
                  value={newCustomer.phone}
                  onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                  placeholder="09XXXXXXXX"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={newCustomer.email}
                  onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                  placeholder="email@example.com"
                />
              </div>
              <div>
                <Label htmlFor="address">Địa chỉ</Label>
                <Textarea
                  id="address"
                  value={newCustomer.address}
                  onChange={(e) => setNewCustomer({ ...newCustomer, address: e.target.value })}
                  placeholder="123 Nguyễn Huệ, Q1, TP.HCM"
                />
              </div>
              <div>
                <Label htmlFor="notes">Ghi chú</Label>
                <Textarea
                  id="notes"
                  value={newCustomer.notes}
                  onChange={(e) => setNewCustomer({ ...newCustomer, notes: e.target.value })}
                  placeholder="Ghi chú thêm về khách hàng..."
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Hủy
              </Button>
              <Button
                onClick={() => {
                  console.log("Creating customer:", newCustomer)
                  setIsCreateDialogOpen(false)
                  setNewCustomer({ name: "", phone: "", email: "", address: "", notes: "" })
                }}
              >
                Tạo khách hàng
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Customer Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tổng khách hàng</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{customers.length}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12</span> khách mới tháng này
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Khách VIP</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{customers.filter((c) => c.status === "vip").length}</div>
            <p className="text-xs text-muted-foreground">Chi tiêu {">"} 50 triệu</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Chi tiêu TB</CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(customers.reduce((sum, c) => sum + c.totalSpent, 0) / customers.length / 1000000)}M₫
            </div>
            <p className="text-xs text-muted-foreground">Trên mỗi khách hàng</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tỷ lệ quay lại</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">75%</div>
            <p className="text-xs text-muted-foreground">Trong 3 tháng qua</p>
          </CardContent>
        </Card>
      </div>

      {/* Customer List */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Danh sách khách hàng</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm theo tên hoặc SĐT..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredCustomers.map((customer) => (
              <div key={customer.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{customer.name}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span className="flex items-center">
                          <Phone className="w-3 h-3 mr-1" />
                          {customer.phone}
                        </span>
                        <span className="flex items-center">
                          <Mail className="w-3 h-3 mr-1" />
                          {customer.email}
                        </span>
                      </div>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <MapPin className="w-3 h-3 mr-1" />
                        {customer.address}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">{getStatusBadge(customer.status)}</div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-gray-50 rounded-lg p-3">
                  <div className="text-center">
                    <p className="text-sm text-gray-500">Tổng chi tiêu</p>
                    <p className="font-bold text-lg text-blue-600">{customer.totalSpent.toLocaleString("vi-VN")}₫</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-500">Số đơn hàng</p>
                    <p className="font-bold text-lg">{customer.orderCount}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-500">Mua gần nhất</p>
                    <p className="font-bold text-lg">{customer.lastPurchase}</p>
                  </div>
                </div>

                <div className="flex justify-end space-x-2 mt-3">
                  <Dialog open={isHistoryDialogOpen} onOpenChange={setIsHistoryDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedCustomer(customer)}>
                        Xem lịch sử
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[700px]">
                      <DialogHeader>
                        <DialogTitle>Lịch sử mua hàng - {selectedCustomer?.name}</DialogTitle>
                        <DialogDescription>Chi tiết các đơn hàng đã mua</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 max-h-[400px] overflow-y-auto">
                        {/* Mock purchase history */}
                        <div className="border rounded p-3">
                          <div className="flex justify-between mb-2">
                            <span className="font-medium">ORD-2024-156</span>
                            <span className="text-sm text-gray-500">2024-01-18</span>
                          </div>
                          <p className="text-sm">iPhone 15 Pro Max 256GB Titan Tự Nhiên</p>
                          <p className="font-bold text-blue-600">34,990,000₫</p>
                        </div>
                        <div className="border rounded p-3">
                          <div className="flex justify-between mb-2">
                            <span className="font-medium">ORD-2024-142</span>
                            <span className="text-sm text-gray-500">2024-01-15</span>
                          </div>
                          <p className="text-sm">iPhone 15 128GB Hồng</p>
                          <p className="font-bold text-blue-600">22,990,000₫</p>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedCustomer(customer)}>
                        Chỉnh sửa
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[500px]">
                      <DialogHeader>
                        <DialogTitle>Chỉnh sửa khách hàng</DialogTitle>
                        <DialogDescription>Cập nhật thông tin cho {selectedCustomer?.name}</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div>
                          <Label>Họ và tên</Label>
                          <Input defaultValue={selectedCustomer?.name} />
                        </div>
                        <div>
                          <Label>Số điện thoại</Label>
                          <Input defaultValue={selectedCustomer?.phone} />
                        </div>
                        <div>
                          <Label>Email</Label>
                          <Input defaultValue={selectedCustomer?.email} />
                        </div>
                        <div>
                          <Label>Địa chỉ</Label>
                          <Textarea defaultValue={selectedCustomer?.address} />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                          Hủy
                        </Button>
                        <Button
                          onClick={() => {
                            console.log("Updating customer:", selectedCustomer?.id)
                            setIsEditDialogOpen(false)
                          }}
                        >
                          Lưu thay đổi
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Button
                    size="sm"
                    onClick={() => {
                      console.log("Creating order for customer:", customer.id)
                      // Logic chuyển sang tab POS với thông tin khách hàng
                    }}
                  >
                    Tạo đơn hàng
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-500 hover:text-red-700 ml-2"
                    onClick={() => {
                      if (confirm(`Bạn có chắc chắn muốn xóa khách hàng ${customer.name}?`)) {
                        console.log("Deleting customer:", customer.id)
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Xóa
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
