"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Search, Plus, UserIcon, Shield, Settings, Trash2, Edit, Eye } from "lucide-react"

interface UserType {
  id: string
  username: string
  fullName: string
  email: string
  phone: string
  role: "admin" | "manager" | "cashier"
  isActive: boolean
  lastLogin: string
  createdAt: string
  permissions: string[]
}

export default function UserManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<UserType | null>(null)

  const [newUser, setNewUser] = useState({
    username: "",
    fullName: "",
    email: "",
    phone: "",
    role: "cashier" as "admin" | "manager" | "cashier",
    password: "",
    confirmPassword: "",
  })

  const users: UserType[] = [
    {
      id: "1",
      username: "admin",
      fullName: "Quản trị viên",
      email: "admin@iphonestore.com",
      phone: "0901234567",
      role: "admin",
      isActive: true,
      lastLogin: "2024-01-22 14:30",
      createdAt: "2024-01-01",
      permissions: ["all"],
    },
    {
      id: "2",
      username: "manager01",
      fullName: "Nguyễn Văn Manager",
      email: "manager@iphonestore.com",
      phone: "0912345678",
      role: "manager",
      isActive: true,
      lastLogin: "2024-01-22 09:15",
      createdAt: "2024-01-05",
      permissions: ["sales", "inventory", "reports", "customers"],
    },
    {
      id: "3",
      username: "cashier01",
      fullName: "Trần Thị Thu Thủy",
      email: "cashier1@iphonestore.com",
      phone: "0923456789",
      role: "cashier",
      isActive: true,
      lastLogin: "2024-01-22 16:45",
      createdAt: "2024-01-10",
      permissions: ["sales", "customers"],
    },
    {
      id: "4",
      username: "cashier02",
      fullName: "Lê Minh Hoàng",
      email: "cashier2@iphonestore.com",
      phone: "0934567890",
      role: "cashier",
      isActive: false,
      lastLogin: "2024-01-15 11:20",
      createdAt: "2024-01-12",
      permissions: ["sales"],
    },
  ]

  const filteredUsers = users.filter(
    (user) =>
      user.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getRoleBadge = (role: string) => {
    switch (role) {
      case "admin":
        return (
          <Badge className="bg-red-100 text-red-800">
            <Shield className="w-3 h-3 mr-1" />
            Quản trị viên
          </Badge>
        )
      case "manager":
        return (
          <Badge className="bg-blue-100 text-blue-800">
            <Settings className="w-3 h-3 mr-1" />
            Quản lý
          </Badge>
        )
      case "cashier":
        return (
          <Badge className="bg-green-100 text-green-800">
            <UserIcon className="w-3 h-3 mr-1" />
            Thu ngân
          </Badge>
        )
      default:
        return <Badge variant="outline">{role}</Badge>
    }
  }

  const handleCreateUser = () => {
    console.log("Creating user:", newUser)
    setIsCreateDialogOpen(false)
    setNewUser({
      username: "",
      fullName: "",
      email: "",
      phone: "",
      role: "cashier",
      password: "",
      confirmPassword: "",
    })
  }

  const handleEditUser = () => {
    console.log("Editing user:", selectedUser)
    setIsEditDialogOpen(false)
    setSelectedUser(null)
  }

  const handleToggleUserStatus = (userId: string) => {
    console.log("Toggling user status:", userId)
  }

  const handleDeleteUser = (userId: string) => {
    if (confirm("Bạn có chắc chắn muốn xóa người dùng này?")) {
      console.log("Deleting user:", userId)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Quản lý người dùng</h2>
          <p className="text-gray-600">Quản lý tài khoản và phân quyền hệ thống</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Thêm người dùng
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Thêm người dùng mới</DialogTitle>
              <DialogDescription>Tạo tài khoản mới cho nhân viên</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="username">Tên đăng nhập</Label>
                  <Input
                    id="username"
                    value={newUser.username}
                    onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                    placeholder="username"
                  />
                </div>
                <div>
                  <Label htmlFor="fullName">Họ và tên</Label>
                  <Input
                    id="fullName"
                    value={newUser.fullName}
                    onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
                    placeholder="Nguyễn Văn A"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    placeholder="user@iphonestore.com"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Số điện thoại</Label>
                  <Input
                    id="phone"
                    value={newUser.phone}
                    onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                    placeholder="09XXXXXXXX"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="role">Vai trò</Label>
                <Select
                  value={newUser.role}
                  onValueChange={(value: "admin" | "manager" | "cashier") => setNewUser({ ...newUser, role: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cashier">Thu ngân</SelectItem>
                    <SelectItem value="manager">Quản lý</SelectItem>
                    <SelectItem value="admin">Quản trị viên</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="password">Mật khẩu</Label>
                  <Input
                    id="password"
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <Label htmlFor="confirmPassword">Xác nhận mật khẩu</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={newUser.confirmPassword}
                    onChange={(e) => setNewUser({ ...newUser, confirmPassword: e.target.value })}
                    placeholder="••••••••"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Hủy
              </Button>
              <Button onClick={handleCreateUser}>Tạo tài khoản</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tổng người dùng</CardTitle>
            <UserIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
            <p className="text-xs text-muted-foreground">{users.filter((u) => u.isActive).length} đang hoạt động</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Quản trị viên</CardTitle>
            <Shield className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{users.filter((u) => u.role === "admin").length}</div>
            <p className="text-xs text-muted-foreground">người</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Quản lý</CardTitle>
            <Settings className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{users.filter((u) => u.role === "manager").length}</div>
            <p className="text-xs text-muted-foreground">người</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Thu ngân</CardTitle>
            <UserIcon className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{users.filter((u) => u.role === "cashier").length}</div>
            <p className="text-xs text-muted-foreground">người</p>
          </CardContent>
        </Card>
      </div>

      {/* Users List */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Danh sách người dùng</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Tìm theo tên, username, email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredUsers.map((user) => (
              <div key={user.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <UserIcon className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{user.fullName}</h3>
                      <p className="text-sm text-gray-500">
                        @{user.username} • {user.email}
                      </p>
                      <p className="text-xs text-gray-400">
                        Tạo: {user.createdAt} • Đăng nhập cuối: {user.lastLogin}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getRoleBadge(user.role)}
                    <Badge variant={user.isActive ? "default" : "secondary"}>
                      {user.isActive ? "Hoạt động" : "Tạm khóa"}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-gray-50 rounded-lg p-3 mb-3">
                  <div>
                    <p className="text-sm text-gray-500">Thông tin liên hệ</p>
                    <p className="font-medium">{user.phone}</p>
                    <p className="text-sm text-gray-600">{user.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Quyền hạn</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {user.permissions.map((permission, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {permission === "all"
                            ? "Toàn quyền"
                            : permission === "sales"
                              ? "Bán hàng"
                              : permission === "inventory"
                                ? "Kho hàng"
                                : permission === "reports"
                                  ? "Báo cáo"
                                  : permission === "customers"
                                    ? "Khách hàng"
                                    : permission}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Switch checked={user.isActive} onCheckedChange={() => handleToggleUserStatus(user.id)} />
                    <span className="text-sm text-gray-600">{user.isActive ? "Hoạt động" : "Tạm khóa"}</span>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4 mr-1" />
                      Xem
                    </Button>
                    <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => setSelectedUser(user)}>
                          <Edit className="w-4 h-4 mr-1" />
                          Sửa
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[600px]">
                        <DialogHeader>
                          <DialogTitle>Chỉnh sửa người dùng</DialogTitle>
                          <DialogDescription>Cập nhật thông tin cho {selectedUser?.fullName}</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Họ và tên</Label>
                              <Input defaultValue={selectedUser?.fullName} />
                            </div>
                            <div>
                              <Label>Email</Label>
                              <Input defaultValue={selectedUser?.email} />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Số điện thoại</Label>
                              <Input defaultValue={selectedUser?.phone} />
                            </div>
                            <div>
                              <Label>Vai trò</Label>
                              <Select defaultValue={selectedUser?.role}>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="cashier">Thu ngân</SelectItem>
                                  <SelectItem value="manager">Quản lý</SelectItem>
                                  <SelectItem value="admin">Quản trị viên</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                            Hủy
                          </Button>
                          <Button onClick={handleEditUser}>Lưu thay đổi</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-500 hover:text-red-700"
                      onClick={() => handleDeleteUser(user.id)}
                    >
                      <Trash2 className="w-4 h-4 mr-1" />
                      Xóa
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
