"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus,
  Package,
  Truck,
  CheckCircle,
  AlertCircle,
  Smartphone,
  Calendar,
  User,
  Eye,
  Edit,
  Trash2,
} from "lucide-react"

export default function InventoryIntake() {
  const [selectedProduct, setSelectedProduct] = useState("")
  const [selectedVariant, setSelectedVariant] = useState("")
  const [imeiList, setImeiList] = useState<string[]>([""])

  const products = [
    {
      id: "1",
      name: "iPhone 15 Pro Max",
      variants: [
        { id: "1-1", storage: "256GB", color: "Titan Tự Nhiên", sku: "IP15PM-256-TN" },
        { id: "1-2", storage: "512GB", color: "Titan Đen", sku: "IP15PM-512-TD" },
      ],
    },
    {
      id: "2",
      name: "iPhone 15 Pro",
      variants: [
        { id: "2-1", storage: "128GB", color: "Titan Tự Nhiên", sku: "IP15P-128-TN" },
        { id: "2-2", storage: "256GB", color: "Titan Xanh", sku: "IP15P-256-TX" },
      ],
    },
  ]

  const recentIntakes = [
    {
      id: "PO-2024-001",
      date: "2024-01-20",
      supplier: "Apple Việt Nam",
      staff: "Nguyễn Văn A",
      totalItems: 25,
      status: "completed",
      products: [
        { name: "iPhone 15 Pro Max 256GB Titan Tự Nhiên", quantity: 15, value: 525000000 },
        { name: "iPhone 15 Pro 128GB Titan Tự Nhiên", quantity: 10, value: 289900000 },
      ],
    },
    {
      id: "PO-2024-002",
      date: "2024-01-18",
      supplier: "Apple Việt Nam",
      staff: "Trần Thị B",
      totalItems: 18,
      status: "completed",
      products: [
        { name: "iPhone 15 256GB Hồng", quantity: 12, value: 275880000 },
        { name: "iPhone 15 128GB Xanh", quantity: 6, value: 137940000 },
      ],
    },
  ]

  const addImeiField = () => {
    setImeiList([...imeiList, ""])
  }

  const updateImei = (index: number, value: string) => {
    const newList = [...imeiList]
    newList[index] = value
    setImeiList(newList)
  }

  const removeImeiField = (index: number) => {
    if (imeiList.length > 1) {
      const newList = imeiList.filter((_, i) => i !== index)
      setImeiList(newList)
    }
  }

  const validateImei = (imei: string) => {
    return imei.length === 15 && /^\d+$/.test(imei)
  }

  const handleConfirmIntake = () => {
    const validImeis = imeiList.filter((imei) => imei.trim() && validateImei(imei.trim()))

    if (validImeis.length === 0) {
      alert("Vui lòng nhập ít nhất một IMEI hợp lệ!")
      return
    }

    if (!selectedProduct || !selectedVariant) {
      alert("Vui lòng chọn sản phẩm và biến thể!")
      return
    }

    const intakeData = {
      productId: selectedProduct,
      variantId: selectedVariant,
      imeis: validImeis,
      supplier: (document.getElementById("supplier") as HTMLInputElement)?.value || "Apple Việt Nam",
      date: (document.getElementById("date") as HTMLInputElement)?.value || new Date().toISOString().split("T")[0],
      notes: (document.getElementById("notes") as HTMLInputElement)?.value || "",
      costPrice: (document.getElementById("costPrice") as HTMLInputElement)?.value || 31000000,
    }

    console.log("Creating intake:", intakeData)
    alert(`Đã tạo phiếu nhập với ${validImeis.length} IMEI`)

    // Reset form
    setSelectedProduct("")
    setSelectedVariant("")
    setImeiList([""])
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Nhập kho</h2>
          <p className="text-gray-600">Quản lý nhập kho sản phẩm iPhone theo IMEI</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Tạo phiếu nhập mới
        </Button>
      </div>

      <Tabs defaultValue="new-intake" className="w-full">
        <TabsList>
          <TabsTrigger value="new-intake">Phiếu nhập mới</TabsTrigger>
          <TabsTrigger value="history">Lịch sử nhập kho</TabsTrigger>
        </TabsList>

        <TabsContent value="new-intake" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Form nhập kho */}
            <div className="lg:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Thông tin phiếu nhập</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Nhà cung cấp</label>
                      <Input id="supplier" placeholder="Apple Việt Nam" />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Ngày nhập</label>
                      <Input id="date" type="date" defaultValue={new Date().toISOString().split("T")[0]} />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Ghi chú</label>
                    <Input id="notes" placeholder="Lô hàng tháng 1/2024..." />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Chọn sản phẩm và biến thể</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Model sản phẩm</label>
                      <select
                        className="w-full p-2 border rounded-md"
                        value={selectedProduct}
                        onChange={(e) => {
                          setSelectedProduct(e.target.value)
                          setSelectedVariant("")
                        }}
                      >
                        <option value="">Chọn model...</option>
                        {products.map((product) => (
                          <option key={product.id} value={product.id}>
                            {product.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Biến thể</label>
                      <select
                        className="w-full p-2 border rounded-md"
                        value={selectedVariant}
                        onChange={(e) => setSelectedVariant(e.target.value)}
                        disabled={!selectedProduct}
                      >
                        <option value="">Chọn biến thể...</option>
                        {selectedProduct &&
                          products
                            .find((p) => p.id === selectedProduct)
                            ?.variants.map((variant) => (
                              <option key={variant.id} value={variant.id}>
                                {variant.storage} - {variant.color}
                              </option>
                            ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Giá nhập (VNĐ)</label>
                    <Input id="costPrice" type="number" placeholder="31000000" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Danh sách IMEI/Serial
                    <Button variant="outline" size="sm" onClick={addImeiField}>
                      <Plus className="w-4 h-4 mr-1" />
                      Thêm IMEI
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {imeiList.map((imei, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="flex-1">
                        <Input
                          placeholder="Nhập IMEI (15 số)..."
                          value={imei}
                          onChange={(e) => updateImei(index, e.target.value)}
                          maxLength={15}
                          className={imei && !validateImei(imei) ? "border-red-500" : ""}
                        />
                        {imei && !validateImei(imei) && (
                          <p className="text-xs text-red-500 mt-1">IMEI phải có đúng 15 chữ số</p>
                        )}
                      </div>
                      {imeiList.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeImeiField(index)}
                          className="text-red-500 hover:text-red-700"
                        >
                          Xóa
                        </Button>
                      )}
                    </div>
                  ))}
                  <p className="text-xs text-gray-500">Mỗi IMEI phải có đúng 15 chữ số và là duy nhất trong hệ thống</p>
                </CardContent>
              </Card>
            </div>

            {/* Tóm tắt phiếu nhập */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Tóm tắt phiếu nhập</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Tổng số IMEI:</span>
                      <span className="font-medium">{imeiList.filter((imei) => imei.trim()).length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Giá nhập ước tính:</span>
                      <span className="font-medium">31,000,000₫ x {imeiList.filter((imei) => imei.trim()).length}</span>
                    </div>
                    <div className="border-t pt-2">
                      <div className="flex justify-between font-medium">
                        <span>Tổng giá trị:</span>
                        <span className="text-blue-600">
                          {(31000000 * imeiList.filter((imei) => imei.trim()).length).toLocaleString("vi-VN")}₫
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Button className="w-full" onClick={handleConfirmIntake}>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Xác nhận nhập kho
                    </Button>
                    <Button variant="outline" className="w-full">
                      Lưu nháp
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Lưu ý quan trọng</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-xs text-gray-600">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-3 h-3 mt-0.5 text-orange-500" />
                    <span>Kiểm tra kỹ IMEI trước khi xác nhận</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-3 h-3 mt-0.5 text-orange-500" />
                    <span>Mỗi IMEI chỉ được nhập một lần</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-3 h-3 mt-0.5 text-orange-500" />
                    <span>Tồn kho sẽ được cập nhật tự động</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Lịch sử nhập kho</CardTitle>
              <CardDescription>Danh sách các phiếu nhập kho đã thực hiện</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentIntakes.map((intake) => (
                <div key={intake.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Package className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{intake.id}</h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span className="flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            {intake.date}
                          </span>
                          <span className="flex items-center">
                            <User className="w-3 h-3 mr-1" />
                            {intake.staff}
                          </span>
                          <span className="flex items-center">
                            <Truck className="w-3 h-3 mr-1" />
                            {intake.supplier}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="default" className="bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Hoàn thành
                      </Badge>
                      <p className="text-sm text-gray-500 mt-1">{intake.totalItems} sản phẩm</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {intake.products.map((product, index) => (
                      <div key={index} className="flex justify-between items-center bg-gray-50 rounded p-2">
                        <div className="flex items-center space-x-2">
                          <Smartphone className="w-4 h-4 text-gray-500" />
                          <span className="text-sm">{product.name}</span>
                        </div>
                        <div className="text-right text-sm">
                          <span className="font-medium">{product.quantity} chiếc</span>
                          <p className="text-gray-500">{product.value.toLocaleString("vi-VN")}₫</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-end space-x-2 mt-3">
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4 mr-1" />
                      Chi tiết
                    </Button>
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4 mr-1" />
                      Chỉnh sửa
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-500 hover:text-red-700"
                      onClick={() => {
                        if (confirm(`Bạn có chắc chắn muốn xóa phiếu nhập ${intake.id}?`)) {
                          console.log("Deleting intake:", intake.id)
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4 mr-1" />
                      Xóa
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
