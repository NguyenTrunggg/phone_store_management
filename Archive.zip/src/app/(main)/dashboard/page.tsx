import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { DollarSign, ShoppingCart, TrendingUp, AlertTriangle, Users, Smartphone } from "lucide-react"

export default function Dashboard() {
  const todayStats = {
    revenue: 125000000,
    orders: 23,
    avgOrderValue: 5434782,
    customers: 18,
  }

  const inventoryAlerts = [
    { model: "iPhone 15 Pro Max", variant: "256GB Titan Tự Nhiên", stock: 2, status: "low" },
    { model: "iPhone 15", variant: "128GB Hồng", stock: 0, status: "out" },
    { model: "iPhone 15 Pro", variant: "512GB Xanh Dương", stock: 1, status: "low" },
  ]

  const topProducts = [
    { name: "iPhone 15 Pro Max 256GB", sold: 8, revenue: 43200000 },
    { name: "iPhone 15 128GB", sold: 6, revenue: 32400000 },
    { name: "iPhone 15 Pro 256GB", sold: 5, revenue: 27000000 },
    { name: "iPhone 14 128GB", sold: 4, revenue: 21600000 },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
        <p className="text-gray-600">Tổng quan hoạt động kinh doanh hôm nay</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Doanh thu hôm nay</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayStats.revenue.toLocaleString("vi-VN")}₫</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12.5%</span> so với hôm qua
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Đơn hàng</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayStats.orders}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+8.2%</span> so với hôm qua
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Giá trị đơn hàng TB</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayStats.avgOrderValue.toLocaleString("vi-VN")}₫</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+3.8%</span> so với hôm qua
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Khách hàng</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayStats.customers}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+15.3%</span> so với hôm qua
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Inventory Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
              Cảnh báo tồn kho
            </CardTitle>
            <CardDescription>Các sản phẩm sắp hết hoặc đã hết hàng</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {inventoryAlerts.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Smartphone className="w-4 h-4 text-gray-500" />
                  <div>
                    <p className="font-medium text-sm">{item.model}</p>
                    <p className="text-xs text-gray-500">{item.variant}</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant={item.status === "out" ? "destructive" : "secondary"}>
                    {item.stock === 0 ? "Hết hàng" : `Còn ${item.stock}`}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Top Products */}
        <Card>
          <CardHeader>
            <CardTitle>Sản phẩm bán chạy</CardTitle>
            <CardDescription>Top sản phẩm có doanh thu cao nhất hôm nay</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {topProducts.map((product, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                  </div>
                  <div>
                    <p className="font-medium text-sm">{product.name}</p>
                    <p className="text-xs text-gray-500">Đã bán: {product.sold} chiếc</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-sm">{product.revenue.toLocaleString("vi-VN")}₫</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Monthly Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Tiến độ doanh thu tháng này</CardTitle>
          <CardDescription>Mục tiêu: 2,500,000,000₫ | Hiện tại: 1,875,000,000₫</CardDescription>
        </CardHeader>
        <CardContent>
          <Progress value={75} className="w-full" />
          <div className="flex justify-between text-sm text-gray-500 mt-2">
            <span>75% hoàn thành</span>
            <span>Còn 625,000,000₫</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
