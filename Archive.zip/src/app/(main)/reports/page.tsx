import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, TrendingDown, DollarSign, Package, BarChart3 } from "lucide-react"

export default function Reports() {
  const salesData = [
    { product: "iPhone 15 Pro Max 256GB Titan Tự Nhiên", quantity: 15, revenue: 524850000, profit: 59850000 },
    { product: "iPhone 15 Pro 128GB Titan Tự Nhiên", quantity: 12, revenue: 347880000, profit: 35880000 },
    { product: "iPhone 15 256GB Hồng", quantity: 10, revenue: 259900000, profit: 39900000 },
    { product: "iPhone 15 128GB Xanh", quantity: 8, revenue: 183920000, profit: 23920000 },
  ]

  const inventoryData = [
    { product: "iPhone 15 Pro Max", variant: "256GB Titan Tự Nhiên", stock: 5, value: 174950000, status: "normal" },
    { product: "iPhone 15 Pro Max", variant: "512GB Titan Đen", stock: 2, value: 81980000, status: "low" },
    { product: "iPhone 15 Pro", variant: "128GB Titan Tự Nhiên", stock: 8, value: 231920000, status: "normal" },
    { product: "iPhone 15", variant: "128GB Hồng", stock: 0, value: 0, status: "out" },
  ]

  const kpiData = [
    { name: "Doanh thu tháng này", value: "1,875,000,000₫", change: "+12.5%", trend: "up" },
    { name: "Số đơn hàng", value: "156", change: "+8.2%", trend: "up" },
    { name: "Giá trị đơn hàng TB", value: "12,019,230₫", change: "+3.8%", trend: "up" },
    { name: "Vòng quay tồn kho", value: "2.4", change: "-5.2%", trend: "down" },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Báo cáo thống kê</h2>
        <p className="text-gray-600">Phân tích doanh thu, tồn kho và các chỉ số KPI</p>
      </div>

      <Tabs defaultValue="sales" className="w-full">
        <TabsList>
          <TabsTrigger value="sales">Báo cáo doanh thu</TabsTrigger>
          <TabsTrigger value="inventory">Báo cáo tồn kho</TabsTrigger>
          <TabsTrigger value="kpi">Chỉ số KPI</TabsTrigger>
        </TabsList>

        <TabsContent value="sales" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Doanh thu tháng này</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,875,000,000₫</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+12.5%</span> so với tháng trước
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Lợi nhuận gộp</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">159,550,000₫</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+8.5%</span> biên lợi nhuận
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Sản phẩm đã bán</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">156 chiếc</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+15.3%</span> so với tháng trước
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Doanh thu theo sản phẩm</CardTitle>
              <CardDescription>Top sản phẩm có doanh thu cao nhất trong tháng</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {salesData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                      </div>
                      <div>
                        <p className="font-medium">{item.product}</p>
                        <p className="text-sm text-gray-500">Đã bán: {item.quantity} chiếc</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">{item.revenue.toLocaleString("vi-VN")}₫</p>
                      <p className="text-sm text-green-600">+{item.profit.toLocaleString("vi-VN")}₫ lợi nhuận</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tổng giá trị tồn kho</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">488,850,000₫</div>
                <p className="text-xs text-muted-foreground">15 sản phẩm trong kho</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Sản phẩm sắp hết</CardTitle>
                <TrendingDown className="h-4 w-4 text-orange-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600">3</div>
                <p className="text-xs text-muted-foreground">Cần nhập thêm hàng</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vòng quay kho</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">2.4</div>
                <p className="text-xs text-muted-foreground">lần/tháng</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Tình trạng tồn kho</CardTitle>
              <CardDescription>Chi tiết tồn kho theo từng biến thể sản phẩm</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {inventoryData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Package className="w-5 h-5 text-gray-500" />
                      <div>
                        <p className="font-medium">{item.product}</p>
                        <p className="text-sm text-gray-500">{item.variant}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="font-medium">{item.value.toLocaleString("vi-VN")}₫</p>
                        <p className="text-sm text-gray-500">{item.stock} chiếc</p>
                      </div>
                      <Badge
                        variant={
                          item.status === "out" ? "destructive" : item.status === "low" ? "secondary" : "default"
                        }
                      >
                        {item.status === "out" ? "Hết hàng" : item.status === "low" ? "Sắp hết" : "Bình thường"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="kpi" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Các chỉ số KPI quan trọng</CardTitle>
              <CardDescription>Theo dõi hiệu quả kinh doanh qua các chỉ số then chốt</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {kpiData.map((kpi, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">{kpi.name}</p>
                      <p className="text-2xl font-bold mt-1">{kpi.value}</p>
                    </div>
                    <div className="text-right">
                      <div className={`flex items-center ${kpi.trend === "up" ? "text-green-600" : "text-red-600"}`}>
                        {kpi.trend === "up" ? (
                          <TrendingUp className="w-4 h-4 mr-1" />
                        ) : (
                          <TrendingDown className="w-4 h-4 mr-1" />
                        )}
                        <span className="font-medium">{kpi.change}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Xu hướng doanh thu 7 ngày</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <BarChart3 className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                    <p>Biểu đồ sẽ được hiển thị ở đây</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Phân tích khách hàng</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Khách hàng mới:</span>
                  <span className="font-bold">23</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Khách hàng quay lại:</span>
                  <span className="font-bold">12</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Tỷ lệ chuyển đổi:</span>
                  <span className="font-bold text-green-600">68.5%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Chi tiêu TB/khách:</span>
                  <span className="font-bold">5,357,142₫</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
